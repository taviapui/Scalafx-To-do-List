package ch.makery.list.view

import ch.makery.list.model.Task
import ch.makery.list.MainApp
import scalafx.scene.control.{TextField, TableColumn, Label, Alert}
import scalafxml.core.macros.sfxml
import scalafx.stage.Stage
import scalafx.Includes._
import ch.makery.list.util.DateUtil._
import scalafx.event.ActionEvent

@sfxml
class TaskUpdateDialogController (

    private val taskField : TextField,
    private val statusField : TextField,
    private val startDateField : TextField,
    private val dueDateField : TextField,
    private val descriptionField : TextField

){
  var         dialogStage : Stage  = null
  private var _task     : Task = null
  var         okClicked            = false

  def task = _task
  def task_=(x : Task) {
        _task = x

        taskField.text = _task.task.value
        statusField.text = _task.status.value

        startDateField.text  = _task.startDate.value.asString
        startDateField.setPromptText("dd.mm.yyyy");

        dueDateField.text  = _task.dueDate.value.asString
        dueDateField.setPromptText("dd.mm.yyyy");

        descriptionField.text = _task.description.value;
  }

  def handleDone(action :ActionEvent){

     if (isInputValid()) {
        _task.task <== taskField.text
        _task.status  <== statusField.text
        _task.startDate.value       = startDateField.text.value.parseLocalDate
        _task.dueDate.value       = dueDateField.text.value.parseLocalDate
        _task.description    <== descriptionField.text;

        okClicked = true;
        dialogStage.close()
    }
  }

  def handleCancel(action :ActionEvent) {
        dialogStage.close();
  }
  def nullChecking (x : String) = x == null || x.length == 0

  def isInputValid() : Boolean = {
    var errorMessage = ""

    if (nullChecking(taskField.text.value))
      errorMessage += "No valid task name!\n"
    if (nullChecking(startDateField.text.value))
      errorMessage += "No valid start date!\n"
    else {
      if (!startDateField.text.value.isValid) {
          errorMessage += "No valid date format. Use the format dd.mm.yyyy!\n";
      }
    }

    if (errorMessage.length() == 0) {
        return true;
    } else {
        // Show the error message.
        val alert = new Alert(Alert.AlertType.Error){
          initOwner(dialogStage)
          title = "Invalid Fields"
          headerText = "Please correct invalid fields"
          contentText = errorMessage
        }.showAndWait()

        return false;
    }
   }
} 
