package ch.makery.list.view
import ch.makery.list.model.Task
import ch.makery.list.MainApp
import scalafx.scene.control.{TableView, TableColumn, Label}
import scalafxml.core.macros.sfxml
import scalafx.beans.property.{StringProperty} 
import scalafx.Includes._
import ch.makery.list.util.DateUtil._
import scalafx.event.ActionEvent
import scalafx.scene.control.Alert
import scalafx.scene.control.Alert.AlertType
import scala.util.{Success,Failure}

@sfxml
class TaskOverviewController(
    private val listTable : TableView[Task],
    private val taskColumn : TableColumn[Task, String],
    private val statusColumn : TableColumn[Task, String],
    private val taskLabel : Label,
    private val statusLabel :  Label,
    private val startDateLabel : Label,
    private val dueDateLabel : Label,
    private val descriptionLabel : Label    
    ) {
  // initialize Table View display contents model
  listTable.items = MainApp.listData
  // initialize columns's cell values
  taskColumn.cellValueFactory = {_.value.task}
  statusColumn.cellValueFactory  = {_.value.status} 

    private def showListDetails (task : Option[Task]) = {
    task match {
      case Some(task) =>
      // Fill the labels with info from the task object.
      taskLabel.text         <== task.task
      statusLabel.text       <== task.status
      descriptionLabel.text  <== task.description;
      // only allow string, start & due date are local date
      startDateLabel.text   = task.startDate.value.asString 
      dueDateLabel.text     = task.dueDate.value.asString 
      
      case None =>
        // task is null, remove all the text.
      taskLabel.text.unbind()
      statusLabel.text.unbind()
      descriptionLabel.text.unbind()
      taskLabel.text        = ""
      statusLabel.text      = ""
      startDateLabel.text   = ""
      dueDateLabel.text     = ""
      descriptionLabel.text = ""
    }    
  }
  showListDetails(None);
  
  listTable.selectionModel().selectedItem.onChange(
      (_, _, newValue) => showListDetails(Option(newValue))
  )

  def handleDeleteTask(action : ActionEvent) = {
    val selectedIndex = listTable.selectionModel().selectedIndex.value
    val selectedTask = listTable.selectionModel().selectedItem.value
    if (selectedIndex >= 0) {
        selectedTask.delete() match{
            case Success(value) => MainApp.listData.remove(selectedIndex)
            case Failure(exception) =>
            val alert = new Alert(AlertType.Error){
                initOwner(MainApp.stage)
                title       = "Unsuccess to delete"
                headerText  = "Database Error"
                contentText = "Database issue failed to delete task."
                }.showAndWait()
        }
    } else {
        // Nothing selected.
        val alert = new Alert(AlertType.Warning){
          initOwner(MainApp.stage)
          title       = "No Selection"
          headerText  = "No Task Selected"
          contentText = "Please select a task in the table."
        }.showAndWait()
    }
  } 

    def handleAddTask(action : ActionEvent) = {
    val task = new Task("","")
    val okClicked = MainApp.showTaskUpdateDialog(task);
        if (okClicked) {
            task.save() match{
                case Success(value) => MainApp.listData += task
                case Failure(exception) =>
                val alert = new Alert(AlertType.Error){
                    initOwner(MainApp.stage)
                    title       = "Failed to save"
                    headerText  = "Database Error"
                    contentText = "Database issue failed to add task."
                    }.showAndWait()
            }
        }
  }
  def handleUpdateTask(action : ActionEvent) = {
    val selectedTask = listTable.selectionModel().selectedItem.value
    if (selectedTask != null) {
        val okClicked = MainApp.showTaskUpdateDialog(selectedTask)

        if (okClicked){
            selectedTask.save() match{
                case Success(value) => showListDetails(Some(selectedTask))
                case Failure(exception) =>
                val alert = new Alert(AlertType.Error){
                    initOwner(MainApp.stage)
                    title       = "Failed to Update"
                    headerText  = "Database Error"
                    contentText = "Database issue failed to Update task."
                    }.showAndWait()
            }
        } 
    } else {
        // Nothing selected.
        val alert = new Alert(Alert.AlertType.Warning){
          initOwner(MainApp.stage)
          title       = "No Selection"
          headerText  = "No Task Selected"
          contentText = "Please select a task in the table."
        }.showAndWait()
    }
  } 

}
