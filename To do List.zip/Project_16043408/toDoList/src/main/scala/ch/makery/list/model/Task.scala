package ch.makery.list.model

import scalafx.beans.property.{StringProperty, ObjectProperty}
import java.time.LocalDate
import ch.makery.list.util.Database
import ch.makery.list.util.DateUtil._
import scalikejdbc._
import scala.util.{ Try, Success, Failure }

class Task (val taskS : String, val statusS : String) extends Database {
	def this()     = this(null, null)
	var task  = new StringProperty(taskS)
	var status   = new StringProperty(statusS)
	var startDate     = ObjectProperty[LocalDate](LocalDate.of(2020, 2, 21))
	//var postalCode = IntegerProperty(1234)
	var dueDate       = ObjectProperty[LocalDate](LocalDate.of(2020, 2, 21))
	var description       = new StringProperty("You may add description")


	def save() : Try[Int] = {
		if (!(isExist)) {
			Try(DB autoCommit { implicit session => 
				sql"""
					insert into task (task, status,
                     startDate, dueDate, description) values 
						(${task.value}, ${status.value}, ${startDate.value.asString},
							${dueDate.value.asString}, ${description.value})
				""".update.apply()
			})
		} else {
			Try(DB autoCommit { implicit session => 
				sql"""
				update task 
				set 
				task  = ${task.value} ,
				status   = ${status.value},
				startDate     = ${startDate.value.asString},
				dueDate       = ${dueDate.value.asString},
				description       = ${description.value}
				 where task = ${task.value} and
				 status = ${status.value}
				""".update.apply()
			})
		}
			
	}
	def delete() : Try[Int] = {
		if (isExist) {
			Try(DB autoCommit { implicit session => 
			sql"""
				delete from task where  
					task = ${task.value} and status = ${status.value}
				""".update.apply()
			})
		} else 
			throw new Exception("Task not Exists in Database")		
	}
	def isExist : Boolean =  {
		DB readOnly { implicit session =>
			sql"""
				select * from task where 
				task = ${task.value} and status = ${status.value}
			""".map(rs => rs.string("task")).single.apply()
		} match {
			case Some(x) => true
			case None => false
		}

	}
}
object Task extends Database{
	def apply (
		taskS : String, 
		statusS : String,
		startDateS : String,
		dueDateS : String,
		descriptionS : String
		) : Task = {

		new Task(taskS, statusS) {
			startDate.value     = startDateS.parseLocalDate
			dueDate.value       = dueDateS.parseLocalDate
			description.value       = descriptionS
		}
		
	}
	def initializeTable() = {
		DB autoCommit { implicit session => 
			sql"""
			create table task (
			  id int not null GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), 
			  task varchar(64), 
			  status varchar(64), 
			  startDate varchar(200),
			  dueDate varchar(100),
			  description varchar(64)
			)
			""".execute.apply()
		}
	}
	
	def getAllTasks : List[Task] = {
		DB readOnly { implicit session =>
			sql"select * from task".map(rs => Task(rs.string("task"),
				rs.string("status"),rs.string("startDate"), 
                rs.string("dueDate"), rs.string("description") )).list.apply()
		}
	}
}
