package ch.makery.list
import scalafx.application.JFXApp
import scalafx.application.JFXApp.PrimaryStage
import scalafx.scene.Scene
import scalafx.Includes._
import scalafxml.core.{NoDependencyResolver, FXMLView, FXMLLoader}
import javafx.{scene => jfxs}
import scalafx.collections.ObservableBuffer
import ch.makery.list.model.Task
import ch.makery.list.view.TaskUpdateDialogController
import scalafx.stage.{Modality,Stage}
import scalafx.scene.image.Image
import ch.makery.list.util.Database

object MainApp extends JFXApp {

    //initialize database
    Database.setupDB()


    /**
     * The data as an observable list of Tasks.
     */
    val listData = new ObservableBuffer[Task]()

    //assign all person into personData array
    listData ++= Task.getAllTasks

  // transform path of RootLayout.fxml to URI for resource location.
  val rootResource = getClass.getResource("view/RootLayout.fxml")
  // initialize the loader object.
  val loader = new FXMLLoader(rootResource, NoDependencyResolver)
  // Load root layout from fxml file.
  loader.load();
  // retrieve the root component BorderPane from the FXML 
  val roots = loader.getRoot[jfxs.layout.BorderPane]
  // initialize stage
  stage = new PrimaryStage {
    title = "To Do List"
    icons += new Image(getClass.getResourceAsStream("images/toDoList.png"))
    scene = new Scene {
      root = roots
    }
  }
  // actions for display list overview window 
  def showListOverview() = {
    val resource = getClass.getResource("view/ListOverview.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load();
    val roots = loader.getRoot[jfxs.layout.AnchorPane]
    this.roots.setCenter(roots)
  } 
  // call to display ListOverview when app start
  showListOverview()

     def showTaskUpdateDialog(task: Task): Boolean = {
    val resource = getClass.getResource("view/TaskUpdateDialog.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load();
    val roots2  = loader.getRoot[jfxs.Parent]
    val control = loader.getController[TaskUpdateDialogController#Controller]

    val dialog = new Stage() {
      initModality(Modality.APPLICATION_MODAL)
      initOwner(stage)
      icons += new Image(getClass.getResourceAsStream("images/toDoList.png"))
      scene = new Scene {
        root = roots2
      }
    }
    control.dialogStage = dialog
    control.task = task
    dialog.showAndWait()
    control.okClicked
  } 
}
